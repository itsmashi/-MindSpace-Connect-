---
name: Serene Pathway
colors:
  surface: '#f1fcf6'
  surface-dim: '#d2dcd7'
  surface-bright: '#f1fcf6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ecf6f0'
  surface-container: '#e6f0eb'
  surface-container-high: '#e0ebe5'
  surface-container-highest: '#dae5df'
  on-surface: '#141d1a'
  on-surface-variant: '#404945'
  inverse-surface: '#29322f'
  inverse-on-surface: '#e9f3ee'
  outline: '#707975'
  outline-variant: '#bfc9c4'
  surface-tint: '#31685a'
  primary: '#024337'
  on-primary: '#ffffff'
  primary-container: '#235b4e'
  on-primary-container: '#98d1c0'
  inverse-primary: '#99d2c1'
  secondary: '#2f6856'
  on-secondary: '#ffffff'
  secondary-container: '#b3efd8'
  on-secondary-container: '#366e5c'
  tertiary: '#294030'
  on-tertiary: '#ffffff'
  tertiary-container: '#405746'
  on-tertiary-container: '#b1ccb6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b5eedd'
  primary-fixed-dim: '#99d2c1'
  on-primary-fixed: '#002019'
  on-primary-fixed-variant: '#155043'
  secondary-fixed: '#b3efd8'
  secondary-fixed-dim: '#98d3bd'
  on-secondary-fixed: '#002118'
  on-secondary-fixed-variant: '#12503f'
  tertiary-fixed: '#cee9d3'
  tertiary-fixed-dim: '#b3cdb7'
  on-tertiary-fixed: '#092012'
  on-tertiary-fixed-variant: '#354c3b'
  background: '#f1fcf6'
  on-background: '#141d1a'
  surface-variant: '#dae5df'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system delivers an empathetic, organized, and deeply reassuring digital environment tailored for educational counseling, academic advising, and student wellness workflows. Designed for two distinct primary user archetypes—students seeking academic navigation or psychological support, and counselors/administrators managing intense caseloads—the visual language prioritizes clarity, emotional decompression, and psychological safety.

The aesthetic blends **Modern Corporate** reliability with **Warm Minimalist** hospitality. It eliminates anxiety-inducing administrative coldness through gentle geometry, tranquil botanical tones, open breathing room, and soft tactile elevation. Every touchpoint feels supportive, patient, and capable, transforming potentially overwhelming consultations into clear, structured steps forward.

## Colors
The palette is grounded in restorative natural tones, paired with pristine neutral layers and high-clarity typographic contrast.

- **Primary (`#235B4E` - Deep Sage / Forest Emerald):** Grounded, authoritative yet serene. Applied to primary interactive controls, main active states, brand anchors, and high-emphasis focal items.
- **Secondary (`#629B87` - Muted Sage):** Provides supportive depth for sub-navigation, secondary buttons, selected tab accents, and calming progress indicators.
- **Tertiary (`#D8F3DC` - Soft Mint Mist):** Calming, luminous highlight used for comfortable container surfaces, active item backdrops, subtle tags, and completed milestones.
- **Neutral (`#505A56` - Warm Slate Slate):** Provides soft, readable structural chrome and muted secondary typography, free of cold mechanical grays.

### Functional & Urgency States
Urgency indicators communicate triage priorities without inducing distress:
- **Normal Support (`#E8F5E9` bg / `#1B5E20` text / `#A5D6A7` border):** Standard check-ins, general advisement, scheduling confirmations.
- **Time-Sensitive (`#FFF8E1` bg / `#8D6E11` text / `#FFE082` border):** Upcoming deadlines, add/drop registration limits, pending counselor feedback.
- **Immediate Support (`#FDF2F2` bg / `#B91C1C` text / `#FCA5A5` border):** Crisis escalation, urgent wellness intervention, welfare check triggers. Always paired with distinct iconography and clear textual labels, never color alone.

### Surface System
- **Background Canvas:** `#F8FAF9` (Warm Chalk)
- **Surface Level 1 (Cards, Modals):** `#FFFFFF` (Pure Crisp White)
- **Surface Level 2 (Nested Panels, Sidebar Sub-sections):** `#F1F5F3` (Tinted Dew)
- **Text High-Contrast Primary:** `#13221C` (Deep Pine Charcoal, 14:1+ contrast against white)
- **Text Muted / Placeholder:** `#606E67`

## Typography
Plus Jakarta Sans provides the ideal synthesis of geometric crispness and humane warmth. Its open apertures, tall x-height, and subtly rounded terminals deliver rapid parsing under administrative stress without clinical detachment.

- **Display & Headlines:** Used deliberately with restrained weights (600 and 700) and slight negative tracking (`-0.01em` to `-0.02em`) to structure intake forms, student profiles, and consultation milestones.
- **Body Styles:** Set with generous line heights (`1.57` to `1.625` ratio) to make clinical notes, student context summaries, and guidance literature effortless to consume.
- **Labels & Badges:** Distinct uppercase or tightened semi-bold metrics retain legibility at small dimensions within calendar blocks, urgency chips, and schedule slots.

## Layout & Spacing
The layout follows a fluid-responsive 12-column grid anchored by soft maximum widths (1440px max content canvas) to prevent stretched reading lines in case logs.

### Responsive Breakpoints & Adapters
- **Desktop (1200px+):** 12 columns, 24px (`1.5rem`) gutters, 48px (`3rem`) margins. Accommodates dual-pane productivity layouts (e.g., persistent counselor case queue on the left 4 columns, interactive session notes and intake history on the right 8 columns).
- **Tablet (768px - 1199px):** 8 columns, 24px (`1.5rem`) gutters, 32px (`2rem`) margins. Sidebars collapse to responsive drawers or sticky horizontal tab structures.
- **Mobile (Below 768px):** 4 columns, 16px (`1rem`) gutters, 16px (`1rem`) margins. Multi-step forms reflow into single-column flows with bottom-anchored action bars for single-handed thumb operation.

### Spatial Rhythm
Internal elements conform to an 8px baseline rhythm. Component padding scales cleanly from `space-sm` (8px) within dense table cells to `space-xl` (40px) inside consultation booking panels and onboarding containers.

## Elevation & Depth
Depth is created through ambient, multi-layered shadows combined with delicate borders, avoiding harsh black drop-shadows.

### Shadow Structure
- **Elevation 0 (Flat Surface):** Default canvas and resting neutral wells. Border: `1px solid #E1E8E5`.
- **Elevation 1 (Cards, List Items, Tiles):**
  - Shadow: `0 1px 3px rgba(35, 91, 78, 0.04), 0 4px 12px rgba(35, 91, 78, 0.03)`
  - Border: `1px solid #E8ECEB`
- **Elevation 2 (Flyouts, Dropdowns, Hovered Consultation Cards):**
  - Shadow: `0 4px 6px -1px rgba(35, 91, 78, 0.06), 0 10px 24px -2px rgba(35, 91, 78, 0.06)`
  - Border: `1px solid #D6DFDC`
- **Elevation 3 (Urgent Modals, Triage Drawers, Alert Sheets):**
  - Shadow: `0 12px 28px -4px rgba(19, 34, 28, 0.12), 0 24px 48px -8px rgba(19, 34, 28, 0.08)`
  - Backdrop: `rgba(19, 34, 28, 0.35)` with `backdrop-filter: blur(4px)`

The subtle green tint (`rgba(35, 91, 78, ...)`) inside the shadows softens edge contrasts, imparting an organic, calm lift rather than a harsh digital extrusion.

## Shapes
Roundedness Level 2 (`0.5rem` base, scaling to `1rem` for large elements and `1.5rem` for cards/panels) establishes an approachable, non-threatening geometry.

- **Inputs, Buttons, Dropdowns:** `rounded-lg` (`0.5rem` / `8px`) to maintain crisp utilitarian alignment while softening actionable boundaries.
- **Cards, Dialogue Boxes, Session Panels:** `rounded-xl` (`1rem` / `16px`) to `rounded-2xl` (`1.5rem` / `24px`), establishing warm visual shelters for sensitive student and advisory notes.
- **Urgency Tags & Status Indicators:** Fully pill-shaped (`9999px`) to create an unmistakable distinction between clickable rectangular actions and informative contextual states.

## Components

### Buttons
- **Primary:** Background `#235B4E`, text `#FFFFFF`, border `none`, `rounded-lg` (8px). Hover: `#1A453B` with smooth 150ms transition. Active: `#13352D`. Focused: 3px outer ring `#D8F3DC`.
- **Secondary:** Background `#F1F5F3`, text `#235B4E`, border `1px solid #D6DFDC`. Hover: `#E1EBE7`.
- **Ghost/Tertiary:** Background `transparent`, text `#235B4E`. Hover: `#F1F5F3`.
- **Destructive/Crisis:** Background `#FDF2F2`, text `#B91C1C`, border `1px solid #FCA5A5`.

### Chips & Urgency Badges
- **Pill Shape:** Height 24px or 28px, rounded full, horizontal padding `space-sm` to `space-md`.
- **Normal Support:** `#E8F5E9` background, `#1B5E20` text, leading dot indicator `#4CAF50`.
- **Time-Sensitive:** `#FFF8E1` background, `#8D6E11` text, leading dot indicator `#FFB300`.
- **Immediate Support:** `#FDF2F2` background, `#B91C1C` text, leading icon (alert triangle) `#DC2626`.

### Cards & Consultation Containers
- Background `#FFFFFF`, border `1px solid #E8ECEB`, radius `16px`, padding `24px`.
- Header row with student meta-information and trailing status chip.
- Subtle divider (`1px solid #F1F5F3`) between appointment agenda notes and counselor action bars.

### Input Fields & Controls
- **Text & Select Fields:** Height 44px, background `#FFFFFF`, border `1px solid #CFD8D5`, text `#13221C`, radius 8px, horizontal padding 14px. Focus state: border `#235B4E`, glow ring `3px rgba(35, 91, 78, 0.15)`.
- **Checkboxes & Radios:** Size 18px, border `2px solid #629B87`, radius 4px (checkbox) or full (radio). Checked state: solid fill `#235B4E` with white checkmark/dot.

### Consultation Timeline & Stepper
- A specialized vertical and horizontal pathway component tracing student milestones (e.g., "Intake Received" -> "Counselor Assigned" -> "Action Plan Drafted" -> "Follow-Up Completed").
- Complete nodes use `#235B4E` with white checkmarks; in-progress nodes feature `#D8F3DC` with a pulsing emerald nucleus; upcoming nodes remain muted with `#CFD8D5` rings.